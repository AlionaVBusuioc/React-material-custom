import React from 'react';
import './App.css';
import { ThemeProvider } from '@material-ui/core/styles';
import theme from './theme';
import {Button, Typography} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
helloThereStyles: {
  fontStyle: "oblique",
  color: "red",
  fontSize: "30px"
},
buttonStyles: {
color: "green",
border: 0
}
});

function App() {
  const classes = useStyles();
  return ( 
    <div className="App">
    <ThemeProvider theme={theme}>
    <Typography  
    className={classes.helloThereStyles}
    variant="h1" 
    color="primary">
    Hello there
    </Typography>
    <Button className={classes.buttonStyles}
     fullWidth>This is my first button</Button>
    <Button color="primary" variant="outlined"> Button</Button>
    <br/>
    <Button color="secondary" variant="text"> Button</Button>
    </ThemeProvider>
    </div>
  );
}

export default App;
